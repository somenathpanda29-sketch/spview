"""RK RATE server. Python 3.12+, standard library only."""
import argparse, datetime as dt, hashlib, hmac, json, os, secrets, sqlite3, time
from decimal import Decimal, InvalidOperation
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

ROOT = Path(__file__).parent
DB = Path(os.getenv('RK_DATABASE', str(ROOT / 'var/rkrate.sqlite3')))
PERMS = ['view_a', 'view_b', 'edit_a', 'edit_b', 'history']
def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def connect():
    c = sqlite3.connect(DB, timeout=30); c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON'); return c
def password_hash(p, salt=None):
    salt = salt or secrets.token_hex(16)
    return salt + ':' + hashlib.pbkdf2_hmac('sha256', p.encode(), salt.encode(), 300000).hex()
def check_password(p, hashed): return hmac.compare_digest(password_hash(p, hashed.split(':')[0]), hashed)
def rate(v):
    try:
        d = Decimal(str(v))
        if not d.is_finite() or d < 0 or d > Decimal('999999999') or d != d.quantize(Decimal('.01')): raise ValueError()
        return str(d.quantize(Decimal('.01')))
    except (InvalidOperation, ValueError): raise ValueError('Rate must be a non-negative amount with at most two decimal places.')
def init():
    DB.parent.mkdir(parents=True, exist_ok=True)
    with connect() as c:
        c.executescript('''
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, username TEXT UNIQUE COLLATE NOCASE, name TEXT, password TEXT, admin INTEGER, active INTEGER, permissions TEXT, groups_json TEXT);
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id), csrf TEXT, expires REAL);
        CREATE TABLE IF NOT EXISTS items(code TEXT PRIMARY KEY,name TEXT,alias TEXT,group_name TEXT,a_rate TEXT,b_rate TEXT);
        CREATE TABLE IF NOT EXISTS changes(id TEXT PRIMARY KEY, item_code TEXT,item_name TEXT,group_name TEXT,field TEXT,old_rate TEXT,new_rate TEXT,user_id TEXT,username TEXT,created_at TEXT,status TEXT,error TEXT,completed_at TEXT,request_key TEXT UNIQUE);
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT);
        CREATE TABLE IF NOT EXISTS attempts(key TEXT PRIMARY KEY,count INTEGER,until REAL);
        ''')
def user_json(u):
    return {k:u[k] for k in ['id','username','name','admin','active']} | {'permissions':json.loads(u['permissions']), 'groups':json.loads(u['groups_json'])}
def allowed(u,p): return bool(u['admin'] or json.loads(u['permissions']).get(p))
def group_allowed(u,g): return bool(u['admin'] or any(x=='*' or x.casefold()==g.casefold() for x in json.loads(u['groups_json'])))
class APIError(Exception):
    def __init__(self,status,message): self.status=status; self.message=message
class Handler(BaseHTTPRequestHandler):
    server_version = 'RKRate'
    def log_message(self,fmt,*args): pass
    def send_json(self,data,status=200,cookie=None):
        b=json.dumps(data).encode(); self.send_response(status)
        self.headers_common(); self.send_header('Content-Type','application/json'); self.send_header('Cache-Control','no-store')
        if cookie: self.send_header('Set-Cookie',cookie)
        self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
    def headers_common(self):
        self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','same-origin')
        self.send_header('X-Frame-Options','DENY')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
    def body(self):
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size>15_000_000: raise APIError(413,'Request too large')
            d=json.loads(self.rfile.read(size));
            if not isinstance(d,dict): raise ValueError()
            return d
        except (ValueError,UnicodeDecodeError): raise APIError(400,'Invalid JSON')
    def session(self,c,write=False):
        cookies=dict(x.strip().split('=',1) for x in self.headers.get('Cookie','').split(';') if '=' in x)
        row=c.execute('SELECT users.*,sessions.csrf FROM sessions JOIN users ON users.id=sessions.user_id WHERE token=? AND expires>? AND active=1',(cookies.get('rk_session',''),time.time())).fetchone()
        if not row: raise APIError(401,'Please sign in')
        if write and not hmac.compare_digest(self.headers.get('X-CSRF-Token',''),row['csrf']): raise APIError(403,'Please reload and try again')
        return row
    def require_admin(self,u):
        if not u['admin']: raise APIError(403,'Admin access required')
    def cookie(self,value):
        return 'rk_session='+value+'; Path=/; HttpOnly; SameSite=Strict; Max-Age='+('43200' if value else '0')+ ('; Secure' if os.getenv('RK_SECURE_COOKIE')=='1' else '')
    def do_GET(self): self.handle_request(False)
    def do_POST(self): self.handle_request(True)
    def handle_request(self,write):
        try:
            path=urlparse(self.path).path; qs=parse_qs(urlparse(self.path).query)
            if not path.startswith('/api/'):
                if write: raise APIError(405,'Method not allowed')
                assets={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/manifest.webmanifest':'manifest.webmanifest','/icon.svg':'icon.svg'}
                if path not in assets: raise APIError(404,'Not found')
                f=ROOT/'web'/assets[path]; b=f.read_bytes(); self.send_response(200); self.headers_common()
                self.send_header('Content-Type',{'html':'text/html','js':'text/javascript','css':'text/css','webmanifest':'application/manifest+json','svg':'image/svg+xml'}[f.suffix[1:]])
                self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
            d=self.body() if write else {}
            with connect() as c:
                if path.startswith('/api/connector/'):
                    self.connector(c,path,d,write); return
                if path=='/api/login' and write:
                    key=self.client_address[0]; t=time.time(); a=c.execute('SELECT * FROM attempts WHERE key=?',(key,)).fetchone()
                    if a and a['until']>t and a['count']>=10: raise APIError(429,'Too many attempts. Try again in 15 minutes.')
                    u=c.execute('SELECT * FROM users WHERE username=? AND active=1',(str(d.get('username','')),)).fetchone()
                    if not u or not check_password(str(d.get('password','')),u['password']):
                        count=(a['count'] if a and a['until']>t else 0)+1
                        c.execute('INSERT OR REPLACE INTO attempts VALUES(?,?,?)',(key,count,t+900)); c.commit(); raise APIError(401,'Incorrect username or password')
                    c.execute('DELETE FROM attempts WHERE key=?',(key,)); token=secrets.token_urlsafe(32); csrf=secrets.token_urlsafe(32)
                    c.execute('DELETE FROM sessions WHERE expires<?',(t,)); c.execute('INSERT INTO sessions VALUES(?,?,?,?)',(token,u['id'],csrf,t+43200))
                    self.send_json({'user':user_json(u),'csrf':csrf},cookie=self.cookie(token)); return
                u=self.session(c,write)
                if path=='/api/me' and not write:
                    m=dict(c.execute('SELECT key,value FROM meta').fetchall())
                    self.send_json({'user':user_json(u),'csrf':u['csrf'],'sync':m}); return
                if path=='/api/logout' and write:
                    c.execute('DELETE FROM sessions WHERE user_id=? AND csrf=?',(u['id'],u['csrf'])); self.send_json({'ok':True},cookie=self.cookie('')); return
                if path=='/api/items' and not write:
                    items=[]
                    for row in c.execute('SELECT * FROM items ORDER BY name COLLATE NOCASE'):
                        if not group_allowed(u,row['group_name']): continue
                        item={k:row[k] for k in ['code','name','alias','group_name']}
                        for f in ['a','b']:
                            if allowed(u,'view_'+f): item[f+'_rate']=row[f+'_rate']
                        items.append(item)
                    self.send_json({'items':items}); return
                if path=='/api/change' and write:
                    field=d.get('field'); code=str(d.get('code','')); key=str(d.get('request_key',''))
                    if field not in ['a_rate','b_rate']: raise APIError(400,'Invalid rate type')
                    if not allowed(u,'edit_'+field[0]) or not allowed(u,'view_'+field[0]): raise APIError(403,'You cannot edit this rate')
                    c.execute('BEGIN IMMEDIATE')
                    item=c.execute('SELECT * FROM items WHERE code=?',(code,)).fetchone()
                    if not item or not group_allowed(u,item['group_name']): raise APIError(403,'Item access denied')
                    previous=c.execute('SELECT * FROM changes WHERE request_key=?',(key,)).fetchone()
                    if previous:
                        if previous['user_id']!=u['id']: raise APIError(409,'Request already used')
                        self.send_json({'id':previous['id'],'status':previous['status']}); return
                    if len(key)<16 or len(key)>100: raise APIError(400,'Missing request identifier')
                    if c.execute("SELECT 1 FROM changes WHERE item_code=? AND field=? AND status IN ('pending','processing')",(code,field)).fetchone(): raise APIError(409,'A change for this rate is already pending')
                    if d.get('expected')!=item[field]: raise APIError(409,'Rate changed. Refresh before editing.')
                    value=rate(d.get('value')); old=item[field]
                    if value==old: raise APIError(400,'Enter a different rate')
                    ident=secrets.token_hex(16)
                    c.execute('INSERT INTO changes VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(ident,code,item['name'],item['group_name'],field,old,value,u['id'],u['username'],now(),'pending','','',key))
                    self.send_json({'id':ident,'status':'pending'}); return
                if path=='/api/history' and not write:
                    if not allowed(u,'history'): raise APIError(403,'History access denied')
                    rows=[]
                    for row in c.execute('SELECT * FROM changes ORDER BY created_at DESC LIMIT 5000'):
                        if group_allowed(u,row['group_name']) and allowed(u,'view_'+row['field'][0]): rows.append(dict(row))
                    self.send_json({'changes':rows}); return
                if path=='/api/users':
                    self.require_admin(u)
                    if not write:
                        self.send_json({'users':[user_json(x) for x in c.execute('SELECT * FROM users ORDER BY username')]}); return
                    username=str(d.get('username','')).strip(); name=str(d.get('name','')).strip()
                    if not username or len(username)>60 or not name or len(name)>100: raise APIError(400,'Name and username required')
                    groups=d.get('groups',[]); perms=d.get('permissions',{})
                    if not isinstance(groups,list) or not all(isinstance(x,str) and len(x)<=200 for x in groups) or not isinstance(perms,dict): raise APIError(400,'Invalid permissions')
                    perms={p:bool(perms.get(p)) for p in PERMS}
                    for f in ['a','b']:
                        if perms['edit_'+f] and not perms['view_'+f]: raise APIError(400,'Editing requires viewing permission')
                    existing=c.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
                    if existing and existing['admin']: raise APIError(400,'Owner account cannot be modified here')
                    pw=str(d.get('password',''))
                    if (not existing or pw) and len(pw)<12: raise APIError(400,'Use a password of at least 12 characters')
                    c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(username) DO UPDATE SET name=excluded.name,password=excluded.password,active=excluded.active,permissions=excluded.permissions,groups_json=excluded.groups_json',(existing['id'] if existing else secrets.token_hex(16),username,name,password_hash(pw) if pw else existing['password'],0,int(bool(d.get('active',True))),json.dumps(perms),json.dumps(groups)))
                    if existing: c.execute('DELETE FROM sessions WHERE user_id=?',(existing['id'],))
                    self.send_json({'ok':True}); return
                raise APIError(404,'Not found')
        except APIError as e: self.send_json({'error':e.message},e.status)
        except ValueError as e: self.send_json({'error':str(e)},400)
        except sqlite3.IntegrityError: self.send_json({'error':'Conflicting record'},409)
        except Exception:
            self.send_json({'error':'Server error. Check server configuration.'},500)
    def connector(self,c,path,d,write):
        token=os.getenv('RK_CONNECTOR_TOKEN','')
        if not token or not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+token): raise APIError(401,'Connector authentication failed')
        if not write: raise APIError(405,'POST required')
        if path=='/api/connector/sync':
            rows=d.get('items')
            if not isinstance(rows,list) or len(rows)>100000: raise APIError(400,'Invalid item snapshot')
            clean=[]; codes=set()
            for x in rows:
                code=str(x['code'])
                if not code or code in codes: raise APIError(400,'Duplicate or empty item code')
                codes.add(code)
                clean.append((code,str(x['name']),str(x.get('alias','')),str(x.get('group','')),rate(x['a_rate']) if x.get('a_rate') not in [None,''] else None,rate(x['b_rate']) if x.get('b_rate') not in [None,''] else None))
            c.execute('BEGIN IMMEDIATE'); c.execute('DELETE FROM items'); c.executemany('INSERT INTO items VALUES(?,?,?,?,?,?)',clean)
            c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('last_sync',now())); self.send_json({'ok':True,'count':len(clean)}); return
        if path=='/api/connector/poll':
            c.execute('BEGIN IMMEDIATE'); c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('connector_seen',now()))
            # One connector is supported. A durable local journal makes redelivery safe.
            rows=c.execute("SELECT * FROM changes WHERE status IN ('pending','processing') ORDER BY created_at LIMIT 20").fetchall()
            jobs=[]
            for row in rows:
                author=c.execute('SELECT * FROM users WHERE id=?',(row['user_id'],)).fetchone()
                if row['status']=='pending' and (not author or not author['active'] or not group_allowed(author,row['group_name']) or not allowed(author,'edit_'+row['field'][0])):
                    c.execute("UPDATE changes SET status='failed',error=?,completed_at=? WHERE id=?",('User no longer has permission to make this change',now(),row['id']))
                    continue
                c.execute("UPDATE changes SET status='processing' WHERE id=?",(row['id'],));jobs.append(dict(row))
            self.send_json({'jobs':jobs}); return
        if path=='/api/connector/result':
            c.execute('BEGIN IMMEDIATE'); row=c.execute('SELECT * FROM changes WHERE id=?',(d.get('id'),)).fetchone()
            if not row: raise APIError(404,'Change not found')
            if row['status'] in ['applied','failed']:
                self.send_json({'ok':True}); return
            if row['status']!='processing': raise APIError(409,'Job has not been claimed')
            ok=d.get('ok') is True
            c.execute('UPDATE changes SET status=?,error=?,completed_at=? WHERE id=?',('applied' if ok else 'failed',str(d.get('error',''))[:500] if not ok else '',now(),row['id']))
            if ok: c.execute('UPDATE items SET '+row['field']+'=? WHERE code=?',(row['new_rate'],row['item_code']))
            self.send_json({'ok':True}); return
        raise APIError(404,'Not found')
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--host',default='127.0.0.1'); ap.add_argument('--port',type=int,default=8080); ap.add_argument('--create-admin',action='store_true'); ap.add_argument('--import-cache'); a=ap.parse_args(); init()
    if a.create_admin:
        import getpass
        username=input('Owner username: ').strip(); pw=getpass.getpass('Owner password (12+ characters): ')
        if not username or len(pw)<12: raise SystemExit('Username and strong password required')
        with connect() as c: c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?,?)',(secrets.token_hex(16),username,'Owner',password_hash(pw),1,1,'{}','["*"]'))
        print('Owner created.'); return
    if a.import_cache:
        data=json.loads(Path(a.import_cache).read_text(encoding='utf-8-sig'))
        with connect() as c:
            for x in data['items']:
                c.execute('INSERT OR REPLACE INTO items VALUES(?,?,?,?,?,?)',(str(x['code']),x['name'],x.get('alias',''),x.get('group',''),rate(x['a_rate']) if x.get('a_rate') not in ['',None] else None,rate(x['b_rate']) if x.get('b_rate') not in ['',None] else None))
            c.execute('INSERT OR REPLACE INTO meta VALUES(?,?)',('last_sync',data.get('updated_at','Imported snapshot')))
        print('Imported snapshot; live BUSY connection not verified.'); return
    print(f'RK RATE listening on {a.host}:{a.port}',flush=True); ThreadingHTTPServer((a.host,a.port),Handler).serve_forever()
if __name__=='__main__': main()
