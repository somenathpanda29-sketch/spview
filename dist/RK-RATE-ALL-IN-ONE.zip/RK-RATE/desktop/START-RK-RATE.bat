@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3 start_desktop.py
goto finish
:usepython
where python >nul 2>nul
if errorlevel 1 goto missing
python start_desktop.py
goto finish
:missing
echo Python is not installed. Install Python 3.12 or newer from https://www.python.org/downloads/windows/
echo Enable "Add Python to PATH" during installation.
:finish
if errorlevel 1 pause
endlocal
