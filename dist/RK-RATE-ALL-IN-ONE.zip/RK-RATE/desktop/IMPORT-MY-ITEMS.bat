@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3 import_items.py
goto finish
:usepython
python import_items.py
:finish
pause
endlocal
