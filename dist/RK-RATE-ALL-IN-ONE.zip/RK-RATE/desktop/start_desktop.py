"""Windows console launcher for the local RK RATE website; Python 3.12+."""
import os, subprocess, sys, time, urllib.request, webbrowser
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 if sys.version_info<(3,12):
  print('Install Python 3.12 or newer from python.org, then run this launcher again.');return 1
 os.chdir(ROOT)
 # This launcher runs a separate local instance, never a configured production DB.
 os.environ['RK_DATABASE']=str(ROOT/'var/desktop.sqlite3')
 os.environ['RK_SECURE_COOKIE']='0'
 sys.path.insert(0,str(ROOT));import server
 server.init()
 with server.connect() as c:owner=c.execute('SELECT 1 FROM users WHERE admin=1').fetchone()
 if not owner:
  print('\nRK RATE - R K SYNTHETICS\nFirst start: create your owner login. No default password is used.\n')
  result=subprocess.run([sys.executable,str(ROOT/'server.py'),'--create-admin'])
  if result.returncode:return result.returncode
 print('\nStarting RK RATE for this computer. Keep this window open.\nPress Ctrl+C to stop.\n')
 process=subprocess.Popen([sys.executable,str(ROOT/'server.py'),'--host','127.0.0.1','--port','8765'])
 try:
  for attempt in range(60):
   if process.poll() is not None:
    print('RK RATE could not start. Check the error above; port 8765 may already be in use.');return 1
   try:
    with urllib.request.urlopen('http://127.0.0.1:8765/',timeout=1) as r:
     if r.status==200:break
   except OSError:time.sleep(.25)
  else:
   print('The server did not become ready.');return 1
  webbrowser.open('http://127.0.0.1:8765/')
  process.wait();return process.returncode
 except KeyboardInterrupt:return 0
 finally:
  if process.poll() is None:
   process.terminate()
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:process.kill();process.wait()
if __name__=='__main__':
 try:sys.exit(main())
 except Exception as exc:
  print('Unable to start RK RATE:',type(exc).__name__);sys.exit(1)
