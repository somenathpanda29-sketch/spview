"""Import item-only data from the user's local original PHP ZIP or cache JSON."""
import json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def load_items(path):
 p=Path(path)
 if p.suffix.lower()=='.zip':
  with zipfile.ZipFile(p) as z:
   names=[n for n in z.namelist() if n.replace('\\','/').endswith('/data/items_cache.json') or n=='data/items_cache.json']
   if len(names)!=1:raise ValueError('Choose the original rateinquiry.zip containing data/items_cache.json.')
   if z.getinfo(names[0]).file_size>30_000_000:raise ValueError('Cache too large')
   data=json.loads(z.read(names[0]).decode('utf-8-sig'))
 else:data=json.loads(p.read_text(encoding='utf-8-sig'))
 if not isinstance(data,dict) or not isinstance(data.get('items'),list):raise ValueError('No item cache found')
 # Copy only catalogue fields; never copy accounts, passwords or purchase prices.
 return {'updated_at':data.get('updated_at','Imported snapshot'),'items':[{k:x.get(k,'') for k in ['code','name','alias','group','a_rate','b_rate']} for x in data['items']]}
def main():
 if sys.version_info<(3,12):raise ValueError('Python 3.12 or newer is required')
 import tkinter as tk
 from tkinter import filedialog
 window=tk.Tk();window.withdraw()
 path=filedialog.askopenfilename(title='Select your original rateinquiry.zip or items_cache.json',filetypes=[('BUSY cache / original ZIP','*.zip *.json')]);window.destroy()
 if not path:return
 data=load_items(path);os.environ['RK_DATABASE']=str(ROOT/'var/desktop.sqlite3')
 (ROOT/'var').mkdir(exist_ok=True)
 with tempfile.TemporaryDirectory(prefix='rk-import-') as tmp:
  file=Path(tmp)/'items.json';file.write_text(json.dumps(data),encoding='utf-8')
  subprocess.run([sys.executable,str(ROOT/'server.py'),'--import-cache',str(file)],check=True)
 print('Imported',len(data['items']),'items. This is a snapshot; live BUSY syncing still needs the connector.')
if __name__=='__main__':
 try:main()
 except Exception as e:print('Import failed:',str(e));sys.exit(1)
