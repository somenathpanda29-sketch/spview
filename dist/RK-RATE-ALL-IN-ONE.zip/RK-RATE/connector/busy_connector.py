"""Run on the BUSY Windows computer. pip install -r requirements.txt"""
import datetime, hashlib, json, os, sqlite3, time, urllib.request
from decimal import Decimal
from pathlib import Path

class Connector:
    def __init__(self):
        self.url=os.environ['RK_SERVER_URL'].rstrip('/')
        if not self.url.startswith('https://') and not (os.getenv('RK_ALLOW_LOCAL_HTTP')=='1' and self.url.startswith('http://127.0.0.1:')):
            raise ValueError('RK_SERVER_URL must use HTTPS')
        self.token=os.environ['RK_CONNECTOR_TOKEN']; self.db_path=os.environ['BUSY_DB_PATH']
        self.journal=sqlite3.connect(Path(__file__).with_name('connector-journal.sqlite3'))
        self.journal.execute('CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY, payload TEXT, state TEXT, result TEXT)')
    def request(self,route,data):
        req=urllib.request.Request(self.url+'/api/connector/'+route,data=json.dumps(data).encode(),headers={'Content-Type':'application/json','Authorization':'Bearer '+self.token},method='POST')
        with urllib.request.urlopen(req,timeout=60) as r: return json.load(r)
    def connect(self):
        import pyodbc
        # ODBC brace escaping preserves paths/passwords without interpolating SQL.
        brace=lambda s:'{'+s.replace('}','}}')+'}'
        driver=os.getenv('BUSY_ODBC_DRIVER','Microsoft Access Driver (*.mdb, *.accdb)')
        cs='DRIVER='+brace(driver)+';DBQ='+brace(self.db_path)+';PWD='+brace(os.getenv('BUSY_DB_PASSWORD',''))+';'
        return pyodbc.connect(cs,autocommit=False)
    def snapshot(self):
        c=self.connect()
        try:
            cur=c.cursor(); groups={str(r[0]).strip():str(r[1] or '').strip() for r in cur.execute('SELECT [Code],[Name] FROM [Master1]')}
            items={}
            for code,name,alias,parent in cur.execute('SELECT [Code],[Name],[Alias],[ParentGrp] FROM [Master1] WHERE [MasterType]=6'):
                code=str(code).strip();items[code]={'code':code,'name':str(name or '').strip(),'alias':str(alias or '').strip(),'group':groups.get(str(parent).strip(),''),'a_rate':None,'b_rate':None}
            for code,cat,value in cur.execute('SELECT [MasterCode],[I1],[D1] FROM [MasterSupport] WHERE [I1] IN (101,102)'):
                code=str(code).strip();field={101:'a_rate',102:'b_rate'}.get(int(cat))
                if code in items and field and value is not None:
                    if items[code][field] is not None: raise ValueError('Duplicate BUSY rate rows; resolve before syncing')
                    items[code][field]=str(Decimal(str(value)).quantize(Decimal('.01')))
            self.request('sync',{'items':list(items.values())})
        finally: c.close()
    def apply(self,job):
        ident=job['id']; payload=json.dumps({k:job[k] for k in ['item_code','field','old_rate','new_rate']},sort_keys=True)
        row=self.journal.execute('SELECT payload,state,result FROM jobs WHERE id=?',(ident,)).fetchone()
        if row and row[0]!=payload: raise ValueError('Job identifier reused with different payload')
        if row and row[1]=='done': return json.loads(row[2])
        recovering=bool(row)
        if not row:
            self.journal.execute('INSERT INTO jobs VALUES(?,?,?,?)',(ident,payload,'applying',''));self.journal.commit()
        c=None
        try:
            if job['field'] not in ['a_rate','b_rate']: raise ValueError('Invalid rate field')
            c=self.connect(); cur=c.cursor();code=job['item_code']; cat=101 if job['field']=='a_rate' else 102
            item=cur.execute('SELECT [Code] FROM [Master1] WHERE [Code]=? AND [MasterType]=6',code).fetchall()
            if len(item)!=1: raise ValueError('BUSY item missing or not unique')
            rows=cur.execute('SELECT [D1] FROM [MasterSupport] WHERE [MasterCode]=? AND [I1]=?',code,cat).fetchall()
            if len(rows)!=1: raise ValueError('BUSY rate row missing or not unique')
            current=Decimal(str(rows[0][0])) if rows[0][0] is not None else None
            expected=Decimal(job['old_rate']) if job['old_rate'] is not None else None
            new=Decimal(job['new_rate'])
            if recovering and current==new:
                result={'id':ident,'ok':True} # Previous commit may have succeeded before acknowledgment.
            else:
                if current!=expected: raise ValueError('BUSY rate changed since the request. Refresh and submit again.')
                if current is None:
                    cur.execute('UPDATE [MasterSupport] SET [D1]=? WHERE [MasterCode]=? AND [I1]=? AND [D1] IS NULL',new,code,cat)
                else:
                    cur.execute('UPDATE [MasterSupport] SET [D1]=? WHERE [MasterCode]=? AND [I1]=? AND [D1]=?',new,code,cat,current)
                check=cur.execute('SELECT [D1] FROM [MasterSupport] WHERE [MasterCode]=? AND [I1]=?',code,cat).fetchall()
                if len(check)!=1 or Decimal(str(check[0][0]))!=new: raise ValueError('BUSY did not confirm the requested rate')
                c.commit(); result={'id':ident,'ok':True}
        except Exception:
            if c:
                try:c.rollback()
                except Exception:pass
            # Do not send raw ODBC errors, connection paths, or passwords to the cloud.
            result={'id':ident,'ok':False,'error':'BUSY update could not be confirmed. Check the local database, item rate and connector configuration before resubmitting.'}
        finally:
            if c:c.close()
        self.journal.execute('UPDATE jobs SET state=?,result=? WHERE id=?',('done',json.dumps(result),ident));self.journal.commit()
        return result
    def run(self):
        synced=0
        while True:
            try:
                # Replay durable confirmations before new jobs, including after restart.
                jobs=self.request('poll',{})['jobs']
                for job in jobs:self.request('result',self.apply(job))
                if time.monotonic()-synced>60:
                    self.snapshot();synced=time.monotonic()
                print(datetime.datetime.now().isoformat(timespec='seconds'),'Connector cycle completed',flush=True)
            except Exception as e:
                print(datetime.datetime.now().isoformat(timespec='seconds'),'Connection cycle failed:',type(e).__name__, '(check configuration/network; details withheld to protect credentials)',flush=True)
            time.sleep(10)
if __name__=='__main__': Connector().run()
