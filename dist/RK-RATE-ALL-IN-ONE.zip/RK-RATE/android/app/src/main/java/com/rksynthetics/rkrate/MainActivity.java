package com.rksynthetics.rkrate;
import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import android.widget.*;

/** HTTPS-only Android client for the shared RK RATE website. No native bridge. */
public class MainActivity extends Activity {
 private WebView web; private String origin;
 @Override public void onCreate(Bundle state) { super.onCreate(state); getWindow().setStatusBarColor(Color.rgb(21,61,53)); getWindow().setNavigationBarColor(Color.rgb(21,61,53));
  String saved=getPreferences(0).getString("server",""); if(saved.isEmpty()) setup(); else open(saved);
 }
 private boolean valid(String url) { try { Uri u=Uri.parse(url); return "https".equals(u.getScheme()) && u.getHost()!=null && u.getUserInfo()==null && (u.getPath()==null || u.getPath().isEmpty() || "/".equals(u.getPath())) && u.getQuery()==null && u.getFragment()==null && (u.getPort()==-1 || u.getPort()==443); } catch(Exception e) { return false; } }
 private void setup() { LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setPadding(48,80,48,48);layout.setBackgroundColor(Color.rgb(246,247,243));
  TextView title=new TextView(this);title.setText("RK RATE\nR K SYNTHETICS");title.setTextSize(28);title.setTextColor(Color.rgb(21,61,53));layout.addView(title);
  TextView hint=new TextView(this);hint.setText("Enter your shop's secure website address. Use only the address provided by your administrator.");hint.setPadding(0,35,0,25);layout.addView(hint);
  EditText input=new EditText(this);input.setHint("https://your-shop-domain.com");input.setInputType(17);input.setSingleLine(true);layout.addView(input);
  Button button=new Button(this);button.setText("Connect to RK RATE");layout.addView(button);button.setOnClickListener(v->{String url=input.getText().toString().trim();if(!valid(url)){input.setError("Enter a valid HTTPS website address without a path");return;}getPreferences(0).edit().putString("server",url).apply();open(url);});setContentView(layout);
 }
 private void open(String url) { origin=url.replaceAll("/$","");web=new WebView(this);web.setBackgroundColor(Color.rgb(246,247,243));web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){Uri u=req.getUrl();Uri base=Uri.parse(origin);boolean same="https".equals(u.getScheme()) && base.getHost().equalsIgnoreCase(u.getHost()) && u.getPort()==base.getPort();return !same;}
   @Override public void onReceivedError(WebView view,WebResourceRequest req,WebResourceError err){if(req.isForMainFrame())new AlertDialog.Builder(MainActivity.this).setTitle("Cannot connect").setMessage("Check your internet connection and shop website address.").setPositiveButton("Retry",(d,w)->web.loadUrl(origin)).setNeutralButton("Change address",(d,w)->reset()).setNegativeButton("Cancel",null).show();}
  });setContentView(web);web.loadUrl(origin);
 }
 private void reset(){CookieManager.getInstance().removeAllCookies(null);WebStorage.getInstance().deleteAllData();if(web!=null){web.clearCache(true);web.destroy();web=null;}getPreferences(0).edit().remove("server").apply();setup();}
 @Override public boolean onCreateOptionsMenu(Menu menu){menu.add("Change shop website");return true;}
 @Override public boolean onOptionsItemSelected(MenuItem item){new AlertDialog.Builder(this).setTitle("Change shop website?").setMessage("This clears your sign-in session on this device.").setPositiveButton("Continue",(d,w)->reset()).setNegativeButton("Cancel",null).show();return true;}
 @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){if(web!=null)web.destroy();super.onDestroy();}
}
