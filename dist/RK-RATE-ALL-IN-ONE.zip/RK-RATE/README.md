# RK RATE — R K SYNTHETICS

A website and Android client for retail and wholesale rate inquiry, backed by a shop-side Windows BUSY connector. A = wholesale, B = retail.

## What's included

- Mobile and desktop catalogue; item name, code, alias, group and visible-rate search; multiple groups; exact/range prices (set minimum = maximum for exact); name/group/rate sorting and pagination.
- Owner-managed users, active/disabled accounts, per-user A/B viewing and editing permissions, and permitted item groups. Empty group selection grants **no** item access.
- Server-enforced permissions: hidden rate fields are absent from API responses and cannot be searched or sorted in the browser. Purchase prices are not uploaded.
- Direct rate requests without a second admin approval. Confirmed prices remain unchanged until the BUSY connector acknowledges the edit.
- Durable pending/processing/applied/failed history, including user, item, group, old/new rate, request and completion timestamps. The UI displays IST. History shows the latest 5,000 permitted records; the database retains earlier records.
- Conflict detection, one outstanding request per item/rate, request idempotency and connector replay journal. Pending requests are cancelled if the author's permission is revoked before being claimed. Already processing requests may finish.
- Android 8+ HTTPS-only WebView app; same website, users, data and permissions. Enter your shop website address on first launch.

## Architecture and original PHP project

```
Browser / RK RATE Android app ──HTTPS──> Python + SQLite website
                                                 ↑
                                      outbound HTTPS polling
                                                 ↑
                                   Windows Python ODBC connector
                                                 ↕
                                   BUSY Microsoft Access database
```

The uploaded PHP was used to understand the working database schema: `Master1` items (`MasterType=6`), `ParentGrp` group codes, and `MasterSupport.I1=101/102`, `D1` prices. The online service is a new Python implementation rather than a deployment of the original PHP files. It requires Python 3.12+ and no server-side third-party packages. The connector replaces the original PHP ODBC read/write operations using parameterized queries. The original PHP ZIP, user accounts, password hashes and private cache are **not** committed or bundled.

The original application is unchanged. Live compatibility with your BUSY version, Access driver and database must be checked on the shop PC. Direct writes follow the uploaded project's schema; verify against a **backup copy** first and confirm that this method is supported for your BUSY installation before production. Only run one connector for this database and online service.

## Run the website locally

```sh
cd /workspace/spview
python3 server.py --create-admin
python3 server.py --port 8080
```

Choose your own owner username and a password of at least 12 characters. There is no default account or default password. The private database is created under `var/`, outside the static asset routes. On another machine use that machine's checkout directory. Each cloud task is already isolated; use the existing checkout and do not create a worktree unless explicitly requested.

Open the local server in your development browser. An empty catalogue is expected until data is imported or synced. Optional one-time import of the `data/items_cache.json` inside your original ZIP:

```sh
python3 server.py --import-cache /path/to/items_cache.json
```

This imports items and prices only, **not** old users, passwords or purchase prices. It is an offline snapshot, not proof of live BUSY connectivity. Do not place this cache inside `web/`.

## Put the website online

You need a persistent Linux hosting service/VPS with Python 3.12+, disk storage, a domain and HTTPS. Static-only hosting cannot run this server. No deployment, DNS change or paid service has been created by this project.

1. Copy project source to `/opt/rkrate`; create an unprivileged `rkrate` system account and writable `/var/lib/rkrate` owned by it. Python must be 3.12+.
2. Create `/etc/rkrate.env` from `deploy/environment.example`, readable only by root and the service account. Generate a random connector token with `python3 -c 'import secrets; print(secrets.token_urlsafe(48))'`; store it securely in both server and Windows connector settings. Never commit it.
3. Create the owner account as the service user with `RK_DATABASE=/var/lib/rkrate/rkrate.sqlite3 python3 /opt/rkrate/server.py --create-admin`. Ensure that account owns the resulting database.
4. Install the supplied systemd service and configure a reverse proxy such as Caddy using `deploy/Caddyfile.example`. Replace its domain, point DNS to the host, enable HTTPS and run the service. Keep `RK_SECURE_COOKIE=1` online; the reverse proxy should be the only public entry point. Expose HTTPS, not the app's port or the BUSY database.
5. Sign in over HTTPS, verify an unauthorized user cannot read rates, then configure the connector and complete one backup-database rate update end to end.
6. Keep encrypted, tested backups of the SQLite database and the Windows connector journal. Use SQLite's online backup API, not just a copy of the main DB while WAL is active. Keep the owner account and connector token private. Rotate the connector token by updating both sides and restarting.

This is an initial single-shop implementation. For a large public deployment, add managed monitoring, password reset, backup automation and infrastructure-level request limits. The built-in threaded HTTP server is intended behind the reverse proxy. Data in a user's already loaded browser cannot be remotely erased immediately; restrictions take effect on subsequent requests, and the UI checks for changes every 30 seconds while active.

## Set up the Windows BUSY connector

1. Back up BUSY and use a test copy first. Install Python 3.12+ and the Microsoft Access Database Engine ODBC driver. Python and driver bitness must match. Use the working database path from your PHP installation, but don't upload its password.
2. Copy `connector/` to a private directory on the shop PC. In PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
$env:RK_SERVER_URL = 'https://YOUR-SHOP-DOMAIN'
$env:RK_CONNECTOR_TOKEN = '<same secure token configured on server>'
$env:BUSY_DB_PATH = 'C:\path\to\BUSY\company.mdb'
# If Access requires a database password, set BUSY_DB_PASSWORD securely.
.\.venv\Scripts\python.exe busy_connector.py
```

Use the actual path and token; do not include angle-bracket placeholders. Keep secret configuration out of source control. For unattended startup, use Windows Task Scheduler under the account that can access BUSY, with a working directory of the connector directory, restart on failure, and prevent overlapping instances. Supply environment variables securely to that task; variables in an interactive PowerShell session do not automatically transfer to scheduled tasks. Optional `BUSY_ODBC_DRIVER` selects the older `Microsoft Access Driver (*.mdb)` when required.

The connector polls every 10 seconds, uploads a full item snapshot every minute, and writes a durable journal alongside itself. Do not delete the journal during recovery. Outbound HTTPS is sufficient; no incoming connection or port-forward to the shop is needed. The shop PC, BUSY data access and internet must be available for fresh sync and edits. The website can show the last synced rates while the connector is offline. Large item catalogues may require tuning the 15 MB upload limit.

Validation on the PC: confirm item/group counts and A/B values; submit one test edit; verify it in BUSY and history; disconnect/reconnect and confirm pending delivery; confirm conflicting edits made in BUSY fail instead of silently overwriting. ODBC errors are sanitized before sending to the website. Check local connectivity/permissions when a generic connector error is reported.

## Android APK

`dist/RK-RATE-test.apk` is an installable **development-signed** APK, package `com.rksynthetics.rkrate`, min Android 8, target Android 15. The signature was verified with Android `apksigner`. No emulator or physical-device run has been performed here. It requires the deployed HTTPS website to do useful work; the APK does not host the database or connect to Access directly. This is a thin Android client, not an offline-native app.

On a test phone allow installation from the source used to transfer the APK, install it and enter the HTTPS website address. Usernames and passwords are the same as the website. A connection failure dialog lets you change the address. For regular customer distribution use a privately retained production signing key and a release build. Keep that key for future updates; the included development key stays in ignored `var/` and is not in the source archive.

Open `android/` in Android Studio and build with JDK 17+, Android SDK 35 and Gradle 8.9 / Android Gradle Plugin 8.7.3. No Gradle wrapper binary is bundled. Alternatively, the tested build path uses Google's Android build-tools 35.0.0, platform 35, Java 21 runtime, and Eclipse ECJ 3.40.0 from Maven Central:

```sh
ANDROID_SDK_ROOT=/path/to/android-sdk ECJ_JAR=/path/to/ecj-3.40.0.jar python3 scripts/build_apk.py
```

Download SDK/compiler tools from their official repositories and verify the official checksums. The script builds and verifies a test-signed APK. The keystore is local to `var/`; default Android development credentials are used for this **test key only**.

## Validation

```sh
python3 -m unittest discover -s tests -v
node --check web/app.js
```

Eleven API/connector tests cover field/group restrictions, session/CSRF checks, private file routes, change lifecycle, failure, numeric validation, idempotency, conflicting BUSY values, and recovery after commit. Connector tests use an ODBC stand-in; they do not establish compatibility with your real BUSY file.

Browser end-to-end test prerequisites: Node 24, Playwright 1.56.1 and `@sparticuz/chromium` 141.0.0. Install these outside the project if desired, then:

```sh
NODE_PATH=/path/to/test-tools/node_modules node tests/browser.cjs
```

This launches a temporary server with generated test users and sample items, checks desktop/mobile workflows and writes `dist/desktop.png` and `dist/mobile.png`. No real business data or permanent account is used. Some managed command sandboxes need permission to open local sockets.

## Windows desktop starter

The complete ZIP includes `desktop/START-RK-RATE.bat`. Extract the entire ZIP, install Python 3.12+ on Windows, then double-click the launcher. It creates a separate private `var/desktop.sqlite3`, asks you to create the owner login on first use, starts a server on port 8765, and opens your browser. Keep the console open while using it. This is a browser-based desktop launcher, **not** a standalone EXE; it has not been run on Windows in this environment.

`desktop/IMPORT-MY-ITEMS.bat` opens a file picker for your original `rateinquiry.zip` or `items_cache.json` and imports catalogue fields only. Read `desktop/READ-ME-FIRST.txt`. To share the same live data with phones, deploy the website online and open that HTTPS address from your desktop browser instead of using the local instance.
