"""Build a test APK using Android SDK and Eclipse compiler; no Gradle required.
Set ANDROID_SDK_ROOT and ECJ_JAR. SDK packages: build-tools;35.0.0, platforms;android-35.
"""
import os, pathlib, subprocess, zipfile
r=pathlib.Path(__file__).resolve().parents[1]; sdk=pathlib.Path(os.environ['ANDROID_SDK_ROOT']); tools=sdk/'build-tools/35.0.0'; platform=sdk/'platforms/android-35/android.jar'; build=r/'android/app/build/manual';build.mkdir(parents=True,exist_ok=True)
def run(*args):subprocess.run([str(x) for x in args],check=True)
manifest=(r/'android/app/src/main/AndroidManifest.xml').read_text().replace('<manifest ', '<manifest package="com.rksynthetics.rkrate" android:versionCode="1" android:versionName="1.0" ')
(build/'AndroidManifest.xml').write_text(manifest)
run(tools/'aapt','package','-f','-M',build/'AndroidManifest.xml','-S',r/'android/app/src/main/res','-I',platform,'--min-sdk-version','26','--target-sdk-version','35','-F',build/'resources.apk')
classes=build/'classes';classes.mkdir(exist_ok=True)
run('java','-jar',os.environ['ECJ_JAR'],'-1.8','-proc:none','-bootclasspath',str(platform)+os.pathsep+str(tools/'core-lambda-stubs.jar'),'-d',classes,r/'android/app/src/main/java/com/rksynthetics/rkrate/MainActivity.java')
classfiles=list(classes.rglob('*.class'));run(tools/'d8','--lib',platform,'--min-api','26','--output',build,*classfiles)
unsigned=build/'unsigned.apk';unsigned.write_bytes((build/'resources.apk').read_bytes())
with zipfile.ZipFile(unsigned,'a') as z:z.write(build/'classes.dex','classes.dex')
run(tools/'zipalign','-f','-p','4',unsigned,build/'aligned.apk')
key=pathlib.Path(os.getenv('RK_DEBUG_KEY',str(r/'var/android-debug.keystore')));key.parent.mkdir(parents=True,exist_ok=True)
if not key.exists(): run('keytool','-genkeypair','-keystore',key,'-storepass','android','-keypass','android','-alias','androiddebugkey','-keyalg','RSA','-keysize','2048','-validity','10000','-dname','CN=RK RATE Development,O=R K SYNTHETICS,C=IN')
out=r/'dist/RK-RATE-test.apk';out.parent.mkdir(exist_ok=True)
run(tools/'apksigner','sign','--ks',key,'--ks-key-alias','androiddebugkey','--ks-pass','pass:android','--key-pass','pass:android','--out',out,build/'aligned.apk')
run(tools/'apksigner','verify','--verbose',out)
print('Built test-signed APK:',out)
