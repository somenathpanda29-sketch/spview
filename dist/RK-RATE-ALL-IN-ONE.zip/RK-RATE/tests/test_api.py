import http.cookiejar, importlib.util, json, os, tempfile, threading, unittest, urllib.request, urllib.error
from pathlib import Path
spec=importlib.util.spec_from_file_location('server',Path(__file__).parents[1]/'server.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
class API(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.temp=tempfile.TemporaryDirectory();s.DB=Path(cls.temp.name)/'test.sqlite3';s.init();os.environ['RK_CONNECTOR_TOKEN']='test-connector-token'
  with s.connect() as c:
   for name,admin,perms,groups in [('owner',1,{},['*']),('retail',0,{'view_b':True,'edit_b':True,'history':True},['Cotton']),('blocked',0,{},[])]:
    c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?,?)',(name,name,name,s.password_hash('a-long-test-password'),admin,1,json.dumps(perms),json.dumps(groups)))
   c.executemany('INSERT INTO items VALUES(?,?,?,?,?,?)',[('1','Cotton fabric','CF','Cotton','100.00','120.00'),('2','Silk fabric','SF','Silk','200.00','250.00')])
  cls.http=s.ThreadingHTTPServer(('127.0.0.1',0),s.Handler);cls.url='http://127.0.0.1:'+str(cls.http.server_port);threading.Thread(target=cls.http.serve_forever,daemon=True).start()
 @classmethod
 def tearDownClass(cls):cls.http.shutdown();cls.http.server_close();cls.temp.cleanup()
 def setUp(self):
  with s.connect() as c:
   c.execute('DELETE FROM changes');c.execute('DELETE FROM sessions');c.execute('DELETE FROM attempts');c.execute("UPDATE items SET b_rate='120.00' WHERE code='1'")
 def client(self,name):
  op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));r=self.req(op,'login',{'username':name,'password':'a-long-test-password'});return op,r['csrf']
 def req(self,op,path,data=None,csrf='',connector=False,status=200):
  headers={'Content-Type':'application/json','X-CSRF-Token':csrf}
  if connector:headers['Authorization']='Bearer test-connector-token'
  req=urllib.request.Request(self.url+'/api/'+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
  try:
   with op.open(req) as r:self.assertEqual(r.status,status);return json.load(r)
  except urllib.error.HTTPError as e:self.assertEqual(e.code,status);return json.load(e)
 def test_permissions(self):
  op,csrf=self.client('retail');rows=self.req(op,'items')['items'];self.assertEqual(len(rows),1);self.assertNotIn('a_rate',rows[0]);self.assertNotIn('purchase_rate',rows[0]);self.assertEqual(rows[0]['b_rate'],'120.00')
  self.req(op,'users',status=403);self.req(op,'change',{'code':'2','field':'b_rate','value':'300','expected':'250.00','request_key':'group-denied-key'},csrf,status=403)
  self.req(op,'change',{'code':'1','field':'a_rate'},csrf,status=403)
 def test_csrf_and_private_files(self):
  op,csrf=self.client('retail');self.req(op,'logout',{},status=403)
  for p in ['/server.py','/var/rkrate.sqlite3','/users.json','/connector/busy_connector.py','/%2e%2e/server.py']:
   with self.assertRaises(urllib.error.HTTPError) as ctx:op.open(self.url+p)
   self.assertEqual(ctx.exception.code,404)
 def test_change_lifecycle(self):
  op,csrf=self.client('retail');payload={'code':'1','field':'b_rate','value':'135.50','expected':'120.00','request_key':'unique-request-key-1234'}
  change=self.req(op,'change',payload,csrf);self.assertEqual(change['status'],'pending');self.assertEqual(self.req(op,'items')['items'][0]['b_rate'],'120.00')
  self.assertEqual(self.req(op,'change',payload,csrf)['id'],change['id'])
  self.req(op,'change',dict(payload,request_key='second-request-key-1234'),csrf,status=409)
  self.req(op,'connector/poll',{},status=401)
  jobs=self.req(op,'connector/poll',{},connector=True)['jobs'];self.assertEqual(jobs[0]['username'],'retail');self.assertEqual(jobs[0]['old_rate'],'120.00')
  self.req(op,'connector/result',{'id':change['id'],'ok':True},connector=True)
  self.req(op,'connector/result',{'id':change['id'],'ok':True},connector=True)
  self.assertEqual(self.req(op,'items')['items'][0]['b_rate'],'135.50');self.assertEqual(self.req(op,'history')['changes'][0]['status'],'applied')
 def test_empty_groups_and_permission_update(self):
  op,csrf=self.client('owner');data={'username':'newuser','name':'New person','password':'a-long-test-password','active':True,'groups':[],'permissions':{'view_a':True}}
  self.req(op,'users',data,csrf);new,ncsrf=self.client('newuser');self.assertEqual(self.req(new,'items')['items'],[])
  self.req(op,'users',dict(data,groups=['Cotton']),csrf);self.req(new,'items',status=401)
 def test_failed_job_and_conflict(self):
  op,csrf=self.client('owner');p={'code':'2','field':'a_rate','value':'210','expected':'200.00','request_key':'failure-test-key-12345'}
  job=self.req(op,'change',p,csrf);self.req(op,'connector/poll',{},connector=True);self.req(op,'connector/result',{'id':job['id'],'ok':False,'error':'Conflict'},connector=True)
  row=next(x for x in self.req(op,'items')['items'] if x['code']=='2');self.assertEqual(row['a_rate'],'200.00')
  self.req(op,'change',dict(p,expected='1',request_key='stale-rate-test-key'),csrf,status=409)
 def test_revoked_pending_permission(self):
  op,csrf=self.client('retail');p={'code':'1','field':'b_rate','value':'150','expected':'120.00','request_key':'revoked-pending-key-1234'}
  job=self.req(op,'change',p,csrf)
  with s.connect() as c:c.execute("UPDATE users SET permissions=? WHERE id='retail'",(json.dumps({'view_b':True,'edit_b':False,'history':True}),))
  try:
   self.assertEqual(self.req(op,'connector/poll',{},connector=True)['jobs'],[])
   self.assertEqual(self.req(op,'history')['changes'][0]['status'],'failed')
  finally:
   with s.connect() as c:c.execute("UPDATE users SET permissions=? WHERE id='retail'",(json.dumps({'view_b':True,'edit_b':True,'history':True}),))
 def test_numeric_validation(self):
  for x in ['NaN','-1','Infinity','1.123','1000000000']:
   with self.assertRaises(ValueError):s.rate(x)
if __name__=='__main__':unittest.main()
