import importlib.util,json,tempfile,unittest,zipfile
from pathlib import Path
spec=importlib.util.spec_from_file_location('desktop_import',Path(__file__).parents[1]/'desktop/import_items.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class DesktopImport(unittest.TestCase):
 def test_original_zip_only_imports_catalogue_fields(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'original.zip'
   with zipfile.ZipFile(p,'w') as z:
    z.writestr('rateinquiry/data/items_cache.json',json.dumps({'items':[{'code':'1','name':'Fabric','a_rate':'100','b_rate':'120','purchase_rate':'70'}]}));z.writestr('rateinquiry/users.json','private accounts')
   d=m.load_items(p);self.assertEqual(d['items'][0]['name'],'Fabric');self.assertNotIn('purchase_rate',d['items'][0]);self.assertNotIn('private accounts',json.dumps(d))
 def test_wrong_zip_is_rejected(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'wrong.zip'
   with zipfile.ZipFile(p,'w') as z:z.writestr('START-HERE.txt','no cache')
   with self.assertRaises(ValueError):m.load_items(p)
