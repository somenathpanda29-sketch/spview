import importlib.util,json,sqlite3,unittest
from decimal import Decimal
from pathlib import Path
spec=importlib.util.spec_from_file_location('connector',Path(__file__).parents[1]/'connector/busy_connector.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class FakeDB:
 def __init__(self,value):self.value=value;self.updates=0;self.commits=0
 def cursor(self):return self
 def execute(self,sql,*args):
  if sql.startswith('SELECT [Code]'):self.rows=[(1,)]
  elif sql.startswith('SELECT [D1]'):self.rows=[(self.value,)]
  elif sql.startswith('UPDATE '):self.value=args[0];self.updates+=1
  else:raise AssertionError(sql)
  return self
 def fetchall(self):return self.rows
 def commit(self):self.commits+=1
 def rollback(self):pass
 def close(self):pass
class ConnectorTest(unittest.TestCase):
 def make(self,value='100.00'):
  c=m.Connector.__new__(m.Connector);c.journal=sqlite3.connect(':memory:');c.journal.execute('CREATE TABLE jobs(id TEXT PRIMARY KEY,payload TEXT,state TEXT,result TEXT)');db=FakeDB(Decimal(value));c.connect=lambda:db;self.addCleanup(c.journal.close)
  return c,db,{'id':'test-job','item_code':'1','field':'a_rate','old_rate':'100.00','new_rate':'110.00'}
 def test_success_and_redelivery(self):
  c,db,j=self.make();self.assertTrue(c.apply(j)['ok']);self.assertEqual(db.value,Decimal('110'));self.assertEqual(db.commits,1);self.assertTrue(c.apply(j)['ok']);self.assertEqual(db.updates,1)
 def test_concurrent_busy_change(self):
  c,db,j=self.make('105.00');self.assertFalse(c.apply(j)['ok']);self.assertEqual(db.updates,0)
 def test_recovery_after_commit(self):
  c,db,j=self.make('110.00');payload=json.dumps({k:j[k] for k in ['item_code','field','old_rate','new_rate']},sort_keys=True);c.journal.execute('INSERT INTO jobs VALUES(?,?,?,?)',(j['id'],payload,'applying',''));c.journal.commit();self.assertTrue(c.apply(j)['ok']);self.assertEqual(db.updates,0)
 def test_reused_identifier_rejected(self):
  c,db,j=self.make();c.apply(j)
  with self.assertRaises(ValueError):c.apply(dict(j,new_rate='999.00'))
