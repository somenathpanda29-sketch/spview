import importlib.util,json,secrets,sys,tempfile
from pathlib import Path
spec=importlib.util.spec_from_file_location('rk',Path(__file__).parents[1]/'server.py');s=importlib.util.module_from_spec(spec);spec.loader.exec_module(s)
temp=tempfile.TemporaryDirectory();s.DB=Path(temp.name)/'ui.sqlite3';s.init();pw=secrets.token_urlsafe(24)
with s.connect() as c:
 c.execute('INSERT INTO users VALUES(?,?,?,?,?,?,?,?)',('owner','owner','Shop owner',s.password_hash(pw),1,1,'{}','["*"]'))
 names=['MALAI SITARA','COTTON PRINT','SILK TOUCH','RAYON PLAIN','CHIFFON FLORAL','LINEN BLEND']
 for i in range(1,94):c.execute('INSERT INTO items VALUES(?,?,?,?,?,?)',(str(i),names[(i-1)%6]+' '+str(i),'RK'+str(i),['Cotton','Silk','Rayon'][(i-1)%3],str(100+i)+'.00',str(130+i)+'.00'))
http=s.ThreadingHTTPServer(('127.0.0.1',0),s.Handler);print(json.dumps({'port':http.server_port,'password':pw}),flush=True);http.serve_forever()
